import React from 'react';

export const PageThree = () => {
    return (
        <div>
            PageThree
        </div>
    );
};

