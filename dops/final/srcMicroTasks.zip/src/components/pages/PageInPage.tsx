import React from 'react';

export const PageInPage = () => {
    return (
        <div>
            PageInPage
        </div>
    );
};

