import React from 'react';

export const PageOne = () => {
    return (
        <div>
            PageOne
        </div>
    );
};

