import React from 'react';

export const ProtectedPage = () => {
    return (
        <div>
            ProtectedPage
            </div>
    );
};
