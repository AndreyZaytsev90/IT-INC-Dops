import React from 'react';

export const Error404 = () => {
    return (
        <div>
            Error404
        </div>
    );
};

