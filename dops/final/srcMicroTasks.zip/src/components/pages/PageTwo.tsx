import React from 'react';

export const PageTwo = () => {
    return (
        <div>
            PageTwo
        </div>
    );
};

