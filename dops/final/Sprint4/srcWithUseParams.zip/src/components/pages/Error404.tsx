import React from 'react';

export const Error404 = () => {
    console.log("RENDERING-ERROR")
    return (
        <div>
            Error404
        </div>
    );
};

