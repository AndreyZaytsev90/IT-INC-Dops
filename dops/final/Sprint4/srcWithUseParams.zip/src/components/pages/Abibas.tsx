import React from 'react';

export const Abibas = () => {
    return (
        <div>
            <h2 style={{display: "flex", justifyContent: "space-between", marginLeft: "15px"}}>ABIBAS</h2>
            <p style={{display: "flex", justifyContent: "space-between", marginLeft: "15px"}}>
                Abibas is a humorous name often used online to describe the Adidas company with a misspelling. In
                reality, Abibas is not an official brand or company. It is simply a popular internet meme based on the
                incorrect spelling of the Adidas name.

                Important: Abibas is not a real company, but a joke based on a misspelling of Adidas.
            </p>
        </div>
    );
};

